// clang-format off

//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by GS.rc
//
// Capture:
#define IDD_CAPTURE                     2090
#define IDC_FILENAME                    2091
#define IDC_CODECS                      2092
#define IDC_BROWSE                      2093
#define IDC_WIDTH                       2094
#define IDC_HEIGHT                      2095
#define IDC_CONFIGURE                   2096
#define IDC_COLORSPACE                  2097

#define IDD_SHADER                      10006
#define IDD_HACKS                       10009
#define IDD_OSD                         10010
#define IDC_STATIC                      -1

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        10019
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         2098
#define _APS_NEXT_SYMED_VALUE           5000
#endif
#endif
