//{{NO_DEPENDENCIES}}
// fichier Include Microsoft Visual C++.
// Utilis� par USBDialog.rc
//
#define IDC_CONFIGURE1_USB              3
#define IDC_CONFIGURE2_USB              4
#define IDD_CONFDLG_USB                 101
#define IDD_CONFIG_USB                  101
#define IDD_DLGMSD_USB                  106
#define IDD_DLGWASAPI_USB               107
#define IDD_DLG_EYETOY_USB              108
#define IDC_LOGGING_USB                 1007
#define IDC_COMBO1_USB                  1008
#define IDC_COMBO2_USB                  1009
#define IDC_LIST1_USB                   1010
#define IDC_COMBO_API1_USB              1010
#define IDC_COMBO3_USB                  1010
#define IDC_COMBO_FFB_USB               1011
#define IDC_COMBO_API2_USB              1011
#define IDC_BUTTON1_USB                 1012
#define IDC_DFP_PASS_USB                1013
#define IDC_EDIT1_USB                   1015
#define IDC_COMBO_WHEEL_TYPE1_USB       1037
#define IDC_COMBO_WHEEL_TYPE2_USB       1038
#define IDC_SLIDER1_USB                 1039
#define IDC_BUFFER1_USB                 1040
#define IDC_COMBOMICAPI_USB             1041
#define IDC_SLIDER2_USB                 1041
#define IDC_BUFFER2_USB                 1042
#define IDC_STATIC_USB                  -1

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        109
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1042
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
