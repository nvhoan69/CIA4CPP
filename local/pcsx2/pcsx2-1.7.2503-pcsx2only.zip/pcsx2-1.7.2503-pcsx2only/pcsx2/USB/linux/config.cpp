/*  PCSX2 - PS2 Emulator for PCs
 *  Copyright (C) 2002-2020  PCSX2 Dev Team
 *
 *  PCSX2 is free software: you can redistribute it and/or modify it under the terms
 *  of the GNU Lesser General Public License as published by the Free Software Found-
 *  ation, either version 3 of the License, or (at your option) any later version.
 *
 *  PCSX2 is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY;
 *  without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR
 *  PURPOSE.  See the GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License along with PCSX2.
 *  If not, see <http://www.gnu.org/licenses/>.
 */

#include "config.h"

#include "USB/configuration.h"
#include "USB/deviceproxy.h"
#include "USB/usb-pad/padproxy.h"
#include "USB/usb-mic/audiodeviceproxy.h"
#include "common/Console.h"

void SysMessage_stderr(const char* fmt, ...)
{
	va_list arglist;

	va_start(arglist, fmt);
	Console.Warning(fmt, arglist);
	va_end(arglist);
}
