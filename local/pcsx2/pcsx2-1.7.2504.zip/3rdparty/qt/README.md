# PCSX2 Qt Binaries

## Windows

You can download the binaries from https://github.com/PCSX2/pcsx2-windows-dependencies

Grab the latest release without symbols (or, if you want to debug Qt, with symbols), and extract it to this directory.

## Linux

TODO